const express = require("express");

const { user_list, signup, signin } = require("../controllers/user.controller");
const router = express.Router();
const jwt = require("jsonwebtoken");
const {
  message_listing,
  create_group,
} = require("../controllers/socket.controller");

// router.get("/", user_list);
// router.post("/sign-up", signup);
router.post("/message-list", message_listing);
router.post("/create-group", create_group);

module.exports = router;
