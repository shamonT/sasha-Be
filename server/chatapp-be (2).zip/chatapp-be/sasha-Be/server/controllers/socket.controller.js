const group = require("../model/group.model");
const message = require("../model/message.model");
const socket = require("../model/socket.model");
const User = require("../model/users.model");

async function addsocketdetails(data, id) {
  let response = await socket.findOne({ email: data.email });

  if (response) {
    await socket.updateOne({ email: data.email }, { $set: { socket_id: id } });
  } else {
    let res = await socket.create({
      email: data.email,
      id: data.id,
      socket_id: id,
    });
  }
}

async function addMessage(data) {
  let details = JSON.parse(data);
  try {
    let response = await message.create({
      receiver: details.receiver,
      message: details.message,
      sender: details.email,
    });

    if (response) {
      return true;
    }
  } catch (error) {
    return false;
  }
}
async function getusersockets(data) {
  try {
    let details = JSON.parse(data);
    console.log(details, "details");

    let response = await socket.find({
      $and: [{ $or: [{ email: details.email }, { email: details.receiver }] }],
    });
    return response;
    console.log(response, "scoekt responseresponse");
  } catch (error) {
    return false;
  }
}
const message_listing = async (req, res) => {
  try {
    let data = req.body;
    // const response = await message.find({
    //   sender: data.email,
    //   receiver: data.receiver,
    // });
    const response = await message.find({
      $or: [
        {
          $and: [{ sender: data.email }, { receiver: data.receiver }],
        },
        {
          $and: [{ sender: data.receiver }, { receiver: data.email }],
        },
      ],
    });

    return res
      .status(201)
      .send({ status: "success", code: 200, data: response });
  } catch (error) {
    res.status(500).send({ error: "something went wrong" });
  }
};
const create_group = async (req, res) => {
  try {
    console.log(req.body, "ddd");
    const { v4: uuidv4 } = require("uuid");

    const uniqueId = uuidv4();
    console.log(uniqueId);
    const response = await group.create({
      groupName: req.body.newGroup.name,
      groupId: uniqueId,
      groupMembers: req.body.newGroup.members,
    });
    console.log(response, "groupresponse");
    if (response) {
      return res.status(201).send({ status: "success", code: 200 });
    }
  } catch (error) {
    return res
      .status(500)
      .send({ status: "error", code: 500, message: "Internal server error" });
  }
};
module.exports = {
  create_group,
  addsocketdetails,
  addMessage,
  message_listing,
  getusersockets,
};
