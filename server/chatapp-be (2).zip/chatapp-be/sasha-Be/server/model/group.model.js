const mongoose = require("mongoose");

const groupSchema = new mongoose.Schema({
  groupName: {
    type: String,
    required: true,
  },
  groupId: {
    type: String,
    required: true,
    unique: true,
  },
  groupMembers: [String], // Array of member names
  groupMessages: [
    {
      groupMember: String, // Name of the member who sent the message
      message: {
        type: String,
        // required: true,
      },
      timestamp: {
        type: Date,
        default: Date.now,
      },
    },
  ],
});

const group = mongoose.model("group", groupSchema);

module.exports = group;
