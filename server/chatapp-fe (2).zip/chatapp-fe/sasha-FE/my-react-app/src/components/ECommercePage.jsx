import React from 'react';
import '../styles/ECommercePage.css';

function ECommercePage() {
  return (
    <div className="ecommerce-page">
      <h1>E-commerce Page</h1>
    </div>
  );
}

export default ECommercePage;
