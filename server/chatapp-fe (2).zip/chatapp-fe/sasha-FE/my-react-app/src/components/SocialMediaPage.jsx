import React from 'react';
import '../styles/SocialMediaPage.css';

function SocialMediaPage() {
  return (
    <div className="social-media-page">
      <h1>Social Media Page</h1>
    </div>
  );
}

export default SocialMediaPage;
