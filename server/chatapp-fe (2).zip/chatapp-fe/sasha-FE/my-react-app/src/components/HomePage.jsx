import React from 'react';
import '../styles/HomePage.css';

function HomePage() {
  return (
    <div className="homepage">
      <h1>Welcome to the Home Page</h1>
    </div>
  );
}

export default HomePage;
